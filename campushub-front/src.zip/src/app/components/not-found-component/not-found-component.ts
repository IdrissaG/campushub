import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-not-found-component',
  imports: [RouterLink],
  standalone: true,
  templateUrl: './not-found-component.html',
  styleUrl: './not-found-component.scss',
})
export class NotFoundComponent {

}
